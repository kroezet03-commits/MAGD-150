
// used drawingContext for the gradient to make it look 3d
// Wanted to do cube but couldnt get it to work.

function setup() 
{
  createCanvas(400, 400);
}

function draw() 
{
  background(30); // dark background so the sphere stands out
  
  // radial gradient
  let myGradient = drawingContext.createRadialGradient(170, 170, 10, 200, 200, 120);
  
 
  myGradient.addColorStop(0,"rgb(255, 255, 10)");   
  myGradient.addColorStop(0.5, "rgb(200, 30, 30)");   
  myGradient.addColorStop(1, "rgb(10, 10, 250)");         
  
  // applying the gradient
  drawingContext.fillStyle = myGradient;

  drawingContext.lineWidth = 2;
  

  ellipse(200, 200, 200, 200);
}