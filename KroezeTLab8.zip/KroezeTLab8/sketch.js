let snow;
let treeImg;

function preload() {
  snow = loadImage('assets/snow.png');
  treeImg = loadImage('assets/tree.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  
  // draw background image
  image(snow, 0, 0, 400, 400);
  
  // push and pop so scale only affects the tree image
  push();
  
  // use mouseX to change image size using scale()
  let s = map(mouseX, 0, width, 0.5, 1.5);
  scale(s);
  
  // draw tree (position values are adjusted smaller because scale multiplies them)
  image(treeImg, 100, 100, 100, 100);
  
  pop();
  
  // text styling requirements
  textFont('Helvetica');
  fill(255, 0, 0);
  stroke(0);
  strokeWeight(2);
  
  // text with width and height box limit
  text("Happy Holidays! Winter is on the way so buy me gifts", 30, 300, 340, 80);
}