
let food = ["Apple", "Banana", "Orange", "Grapes", "Almond", "Bread"];
let drink = ["milk", "OJ", "juice", "water", "soda"];
let myFood = [];
let myFoodX = [];
let myFoodY = [];


let thirdArray = food.concat(drink);
    console.log(thirdArray);


let pick1 = food.splice(0,1);
let pick2 = drink.splice(0,1);
let pick3 = thirdArray.pop();


console.log("Array 1: " + food);
console.log("Array 2: " + drink);

function setup() {
  createCanvas(400, 400);
  
  // loops 5 times to pick random foods and give them random coordinates
  for (let p = 0; p < 5; p++) {
    let num = Math.floor(random(0, food.length));
    myFood.push(food[num]);
    myFoodX.push(random(10,220));
    myFoodY.push(random(10,220));
  }
}

function draw() {
  background(240); 
  
  // draws the random foods onto the canvas
  for (let p = 0; p < myFood.length; p++) {
    text(myFood[p], myFoodX[p], myFoodY[p]);
  }
  
  // writes the text on the canvas
  text("Array 1:" + food, 20, 240);
  text("Array 2:" + drink, 20, 260);
  text("Random 1:" + pick1, 20, 280);
  text("Random 2:" + pick2, 20, 300);
  text("Random 1&2: " +pick3, 20, 320);
}